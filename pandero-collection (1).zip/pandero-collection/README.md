# Pandero Collection – Catálogo Digital

Catálogo moderno, minimalista y elegante de zapatillas originales.  
Diseñado para publicarse gratis con **GitHub Pages**.

## Características

- Página de inicio atractiva con branding
- Grid de productos centrado en la imagen
- Búsqueda por nombre / marca
- Filtro por marca
- Filtros de color (etiquetas visuales)
- Botón de WhatsApp Business en cada producto y en el header
- Modal de detalle
- Sección de modalidades de pago (Semanal / Quincenal / Rifa)
- Totalmente responsive
- Estilo navy + gold elegante

## Cómo publicarlo en GitHub Pages (gratis)

1. Crea una cuenta en [GitHub](https://github.com) si no tienes.
2. Crea un **nuevo repositorio** (ejemplo: `pandero-collection`).
3. Sube **todos los archivos** de esta carpeta:
   - `index.html`
   - `styles.css`
   - `app.js`
   - `products.js`
4. Ve a **Settings → Pages**.
5. En **Source** elige la rama `main` (o `master`) y carpeta `/ (root)`.
6. Guarda. En 1-2 minutos tendrás un enlace tipo:  
   `https://tu-usuario.github.io/pandero-collection`

## Cómo editar / agregar productos

Abre el archivo **`products.js`**.

Cada producto tiene esta estructura:

```js
{
  id: 13,                          // número único
  name: "Air Max 90",              // nombre del modelo
  brand: "Nike",                   // marca
  colors: ["blanco", "negro"],     // colores disponibles
  category: "Running",             // opcional
  image: "https://...",            // URL de la foto
  featured: false                  // true = badge "Destacado"
}
```

Colores válidos: `blanco`, `negro`, `rojo`, `azul`, `verde`, `beige`, `rosa`, `gris`, `dorado`.

**Número de WhatsApp**: edita la constante `WHATSAPP_NUMBER` al final de `products.js`  
(formato: código de país + número, sin `+` ni espacios. Ejemplo Perú: `51912345678`).

## Recomendaciones de imágenes

- Sube las fotos a una carpeta `images/` dentro del mismo repositorio y usa rutas relativas:  
  `image: "images/air-max.jpg"`
- O usa un servicio gratuito (Cloudinary, ImgBB, etc.) y pega la URL directa.
- Ideal: fotos con fondo limpio, proporción cuadrada.

## Personalización rápida

- Colores: edita las variables CSS en `styles.css` (`:root`).
- Textos del hero y secciones: edita `index.html`.
- Redes sociales: busca los enlaces de Instagram/Facebook en `index.html`.

---

Hecho para **Pandero Collection** · Estilo moderno minimalista navy + gold.
